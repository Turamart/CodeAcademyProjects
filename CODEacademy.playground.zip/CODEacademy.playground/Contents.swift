import UIKit
var greeting1 = "Vakaras"
var greeting = "Labas"
print(greeting)
print (greeting1)

